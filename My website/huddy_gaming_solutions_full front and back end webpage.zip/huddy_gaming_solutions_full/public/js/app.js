// Simple client-side utilities (kept minimal)
console.log('HUDDY frontend loaded');