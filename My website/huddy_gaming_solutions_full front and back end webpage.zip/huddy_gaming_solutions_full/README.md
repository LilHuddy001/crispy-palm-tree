HUDDY GAMING SOLUTIONS
Full Backend (Node.js + Express + SQLite) + Frontend bundle

What's included:
- server/ (backend)
  - package.json
  - server.js
  - db.js
  - routes/auth.js
  - middleware/auth.js
  - .env.example
- public/ (frontend served statically)
  - index.html
  - signup.html
  - login.html
  - dashboard.html
  - css/style.css
  - js/app.js
- README.md (this file)

Quick start (on your machine):
1. Install Node.js (v16+ recommended).
2. Extract the zip.
3. cd huddy_gaming_solutions_full/server
4. npm install
5. Copy .env.example to .env and edit JWT_SECRET if desired.
6. npm start
7. Open http://localhost:4000 in your browser.

Notes:
- This demo uses SQLite (file-based) for easy setup.
- Passwords are hashed with bcrypt.
- Authentication uses JWT stored in localStorage by the frontend demo.
- For production: use HTTPS, secure cookies or other storage, and a production DB.